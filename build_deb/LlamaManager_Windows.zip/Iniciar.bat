@echo off
cd /d "%~dp0"
LlamaManager-Server.exe
