LlamaManager para Windows - V4 (Arreglo Vulkan CPU-only automático)

1. Haz doble clic en "Iniciar.bat"
2. La aplicación se abrirá directamente en tu navegador (sin mostrar la terminal).
3. Todo el control (incluyendo la consola) está integrado en la web.
4. Cuando termines, simplemente CIERRA tu navegador.
5. LlamaManager detectará que cerraste la web y se apagará solo tras 2 minutos, liberando tu memoria RAM.
